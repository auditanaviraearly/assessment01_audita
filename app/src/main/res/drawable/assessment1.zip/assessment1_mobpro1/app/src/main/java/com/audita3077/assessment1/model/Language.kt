package com.audita3077.assessment1.model

enum class Language {
    ID,EN
}