package com.audita3077.assessment1.model

data class HerbalItem(
    val name: String,
    val imageRes: Int,
    val description: String
)
